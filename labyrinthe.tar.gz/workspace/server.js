var express = require('express');
var mongodb = require('mongodb');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

// On crée l'application web

var app = express();


// On configure le dossier contenant les templates
app.set('views', '.');


// Configuration des middlewares
app
    .use(bodyParser.urlencoded({
        extended: false
    }))
    .use(cookieParser())
    .use(express.static('.'))
    .use(bodyParser.json());

//connexion avec la base de données Mongodb
var MongoClient = require('mongodb').MongoClient,
    assert = require('assert');

// Connection URL
var conn;
var url = 'mongodb://localhost:27017/labyrinthe';

MongoClient.connect(url, function(err, db) {
    assert.equal(null, err);
    conn = db;
    console.log("Connected correctly to server");
});
//gestionnaire qui récupère les données envoyées 
//du cote client et les insère dans la base de données mongodb

app.all('/data', function(req, res, db) {
    res.json(req.body);
    var collection = conn.collection('maze');
    collection.update({ "_id": req.body["_id"] }, req.body, { upsert: true });// verifie si un document porte le nom contenu dans req.body["id"] . Si non, crée le document. Si oui, modifie le document.
                                                                              // Cela assure que chaque nom de labyrinthe n'apparait qu'une fois , cependant, sauvegarder sous un meme nom ecrase la sauvegarde précédente.
   /* collection.insert([req.body], function(err, result) {
        if (err) {
            res.send(500, err);
            
        }
        console.log("maze has been inserted");

    }
    );*/
});

//gestionnaire qui permet de récupérer des valeurs
//pour charger le labyrinthe
app.all('/page', function(req, res) {

var valeur = req.body['nom'];

    var collection = conn.collection('maze');
    
    
    collection.find({labyname: valeur}).toArray(function(err, docs) {
        if (err) {
            return res.send(500, err);
        }

        console.log(docs);
        
        return res.json(docs);

    });
});

app.listen(8080);