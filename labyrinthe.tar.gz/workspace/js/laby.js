//Projet AWS Labyrinthe
//Auteurs :
//EPINETTE Lucas
//BELIZAIRE Cleefton
//ZHANG Nan
//Une fois le serveur lancé, l'application peut être utilisée à l'adresse https://labyrinthe-lucasep.c9.io/html/welcome.html 
//(ou https://labyrinthe-lucasep.c9.io/html/index.html)


var div = document.querySelector("#plateau");
var table = document.createElement('table');
var browser = navigator.userAgent.toLowerCase();
if (browser.indexOf('firefox') > -1) {//Si le navigateur utilisé est firefox, modifie l'affichage du 2D ( mal supporté sous firefox)
	table.style.borderCollapse = "separate";
}
//permet de cacher le plateau 
//lorsque les scripts s'exécutent
div.innerHTML = ' ';

//déclaration de variables globales

var laby = new Array();
var charge;
var labymaze;
var arrLaby;
var col;
var line;
var coldep;
var linedep;
var colarr;
var linearr;

//création du plateau avec bordure
//lignes et colonnes
var tableau = [];
for (var i = 0; i < 9; i++) {
	tableau[i] = [];
	var tr = document.createElement('tr');

	table.appendChild(tr);
	for (var j = 0; j < 9; j++) {

		var td = document.createElement('td');
		tableau[i][j] = td;
		tr.appendChild(td);
		td.dataset['column'] = j;
		td.dataset['line'] = i;
		td.setAttribute("class", 'line' + i + ' column' + j);
		td.style.borderBottomColor = "black";
		td.style.borderRightColor = "black";
	}
}
div.appendChild(table);

//fonction qui permet de conventionner 
//les couleurs gray, black, red, green et yellow
function coulToInt(coul) {
	if (coul == "gray")
		return 0;
	else if (coul == "black")
		return 1;
	else if (coul == "red")
		return 2;
	else if (coul == "green")
		return 3;
	else if (coul == "yellow")
		return 4;
}


//fonction qui récupère le labyrinthe 2D
// sous format array
function recup2D() {
	var labyrinthe = new Array();
	var couleur;
	var lignes = new Array();
	var colonnes = new Array();
	for (var j = 0; j < 9; j++) {
		lignes[j] = new Array();

		for (var i = 0; i < 9; i++) {
			var caseA = document.getElementsByClassName("line" + j + " column" + i);
			lignes[j][i] = coulToInt(caseA[0].style.borderRightColor);

		}
	}
	for (j = 0; j < 9; j++) {
		colonnes[j] = new Array();

		for (var i = 0; i < 9; i++) {
			caseA = document.getElementsByClassName("line" + j + " column" + i);
			colonnes[j][i] = coulToInt(caseA[0].style.borderBottomColor);


		}
	}
	var nomlabyrinthe = document.getElementsByName("nomlaby")[0].value;


	labyrinthe[0] = lignes;
	labyrinthe[1] = colonnes;
	if(linedep!=null)
		labyrinthe[2] = linedep;
	else
		labyrinthe[2] = "0";
	if(coldep!=null)
		labyrinthe[3] = coldep;
	else
		labyrinthe[3] = "0";
	if(linearr!=null)
		labyrinthe[4] = linearr;
	else
		labyrinthe[4] = "0";
	if(colarr!=null)
		labyrinthe[5] = colarr;
	else
		labyrinthe[5] = "0";
	labyrinthe[6] = nomlabyrinthe;
	return labyrinthe;
}

//fonction qui permet de sauvegarder le labyrinthe
function sauvegarde() {
	var couleur;
	var lignes = new Array();
	var colonnes = new Array();
	for (var j = 0; j < 9; j++) {
		lignes[j] = new Array();

		for (var i = 0; i < 9; i++) {
			var caseA = document.getElementsByClassName("line" + j + " column" + i);
			lignes[j][i] = coulToInt(caseA[0].style.borderRightColor);

		}
	}
	for (j = 0; j < 9; j++) {
		colonnes[j] = new Array();

		for (var i = 0; i < 9; i++) {
			caseA = document.getElementsByClassName("line" + j + " column" + i);
			colonnes[j][i] = coulToInt(caseA[0].style.borderBottomColor);


		}
	}
	var nomlabyrinthe = document.getElementsByName("nomlaby")[0].value;


	laby[0] = lignes;
	laby[1] = colonnes;
	laby[2] = linedep;
	laby[3] = coldep;
	laby[4] = linearr;
	laby[5] = colarr;
	laby[6] = nomlabyrinthe;
	send();

}



//fonction qui envoie au serveur 
//le labyrinthe sauvegardé en format 
function send() {
	labymaze = {
		_id : document.getElementsByName("nomlaby")[0].value,
		'labyname': document.getElementsByName("nomlaby")[0].value,
		data: JSON.stringify(laby)
	}
	$.ajax({
		type: "post",
		url: "https://labyrinthe-lucasep.c9.io/data",
		data: labymaze,
	});
}

//fonction qui permet de charger un labyrinthe
//enregistré dans la base de données
function loadAjax() {
	var ajax = new XMLHttpRequest();
	var field = {
		nom: document.getElementById("myField").value// on récupère le nom du labyrinthe sur la page
	};
	var labylaby =
		$.ajax({
			url: "https://labyrinthe-lucasep.c9.io/page",
			data: field,
			async: false,
			type: "POST"
		})
		.done(function(data) {
			arrLaby = data[0].data;
		})
		.fail(function() {
			alert("Error");
		});
//	console.log(arrLaby);
	arrLaby = $.parseJSON(arrLaby);
	PreparerLabyrinthe(arrLaby);

}

//change l'affichage du labyrinthe avec celui contenu en paramètre
function PreparerLabyrinthe(arrLaby) {
	for (var j = 0; j < 9; j++) {
		for (i = 0; i < 9; i++) {

			if (arrLaby[1][i][j] == 0) {
				document.querySelector('.line' + i + '.column' + j).style.borderBottom = "none";
				document.querySelector('.line' + i + '.column' + j).style.borderBottomColor = "gray";
			}
			else if (arrLaby[1][i][j] == 1) {
				document.querySelector('.line' + i + '.column' + j).style.borderBottom = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderBottomColor = "black";
			}
			else if (arrLaby[1][i][j] == 2) {
				document.querySelector('.line' + i + '.column' + j).style.borderBottom = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderBottomColor = "red";
			}
			else if (arrLaby[1][i][j] == 3) {
				document.querySelector('.line' + i + '.column' + j).style.borderBottom = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderBottomColor = "green";
			}
			else if (arrLaby[1][i][j] == 4) {
				document.querySelector('.line' + i + '.column' + j).style.borderBottom = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderBottomColor = "yellow";
			}

			if (arrLaby[0][i][j] == 0) {
				document.querySelector('.line' + i + '.column' + j).style.borderRight = "none";
				document.querySelector('.line' + i + '.column' + j).style.borderRightColor = "gray";
			}
			else if (arrLaby[0][i][j] == 1) {
				document.querySelector('.line' + i + '.column' + j).style.borderRight = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderRightColor = "black";
			}
			else if (arrLaby[0][i][j] == 2) {
				document.querySelector('.line' + i + '.column' + j).style.borderRight = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderRightColor = "red";
			}
			else if (arrLaby[0][i][j] == 3) {
				document.querySelector('.line' + i + '.column' + j).style.borderRight = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderRightColor = "green";
			}
			else if (arrLaby[0][i][j] == 4) {
				document.querySelector('.line' + i + '.column' + j).style.borderRight = "solid";
				document.querySelector('.line' + i + '.column' + j).style.borderRightColor = "yellow";
			}
		}
	}
	document.getElementsByName("nomlaby")[0].value = arrLaby[6];
	document.querySelector('.line' + arrLaby[2] + '.column' + arrLaby[3]).style.background = "blue";
	document.querySelector('.line' + arrLaby[4] + '.column' + arrLaby[5]).style.background = "red";
	if (coldep!=null)
	{
		document.querySelector('.line' + linedep + '.column' + coldep).style.background = "gray";
	}
	if(colarr!=null)
	{
		document.querySelector('.line' + linearr + '.column' + colarr).style.background = "gray";
	}
}





//fonction qui permet de placer le départ, l'arrivée
//effacer des murs, colorer des murs
function action(e) {


	var coulMur = $('input[name="mur"]:checked').val();


	if (col != null && line != null) {
		var col2 = e.target.getAttribute("data-column");
		var line2 = e.target.getAttribute("data-line");
		if ((col2 == col && line2 == line - 1) || (col2 == col && line == line2 - 1) || (line2 == line && col2 == col - 1) || (line2 == line && col == col2 - 1)) {

			if (line2 > line) {
				if (coulMur == "gray") {
					document.querySelector('.line' + line + '.column' + col).style.borderBottom = "none";
				}
				else
					document.querySelector('.line' + line + '.column' + col).style.borderBottom = "solid";
				document.querySelector('.line' + line + '.column' + col).style.borderBottomColor = coulMur;

			}
			else if (line2 < line) {
				if (coulMur == "gray") {
					document.querySelector('.line' + line2 + '.column' + col).style.borderBottom = "none";
				}
				else
					document.querySelector('.line' + line2 + '.column' + col).style.borderBottom = "solid";
				document.querySelector('.line' + line2 + '.column' + col).style.borderBottomColor = coulMur;

			}
			else if (col2 > col) {
				if (coulMur == "gray") {
					document.querySelector('.line' + line + '.column' + col).style.borderRight = "none";
				}
				else
					document.querySelector('.line' + line + '.column' + col).style.borderRight = "solid";
				document.querySelector('.line' + line + '.column' + col).style.borderRightColor = coulMur;

			}
			else {
				if (coulMur == "gray") {
					document.querySelector('.line' + line + '.column' + col2).style.borderRight = "none";
				}
				else
					document.querySelector('.line' + line + '.column' + col2).style.borderRight = "solid";
				document.querySelector('.line' + line + '.column' + col2).style.borderRightColor = coulMur;

			}

		}
		else

			col = null;
		line = null;
		col2 = null;
		line2 = null;
	}

	else {
		col = e.target.getAttribute("data-column");
		line = e.target.getAttribute("data-line");
	}
	if (coulMur == "depart") {
		document.querySelector('.line' + line + '.column' + col).style.background = "blue";

		if (coldep != null) {
			var caseB = document.getElementsByClassName("line" + linedep + " column" + coldep);
			document.querySelector('.line' + linedep + '.column' + coldep).style.background = "gray";

		}
		coldep = col;
		linedep = line;
		col = null;
		line = null;
		col2 = null;
		line2 = null;

	}
	else if (coulMur == "arrivee") {
		document.querySelector('.line' + line + '.column' + col).style.background = "red";

		if (colarr != null) {
			document.querySelector('.line' + linearr + '.column' + colarr).style.background = "gray";

		}
		colarr = col;
		linearr = line;
		col = null;
		line = null;
		col2 = null;
		line2 = null;

	}

}



// Partie 3D


var camera, scene, renderer;
var geometry, material, mesh;
var controls;

var objects = [];

var raycaster;
var raycaster2;
var raycaster3;
var raycaster4;

// crée le labyrinthe en 3D, l'affiche, et gère les déplacements.
function troid() {
	if (arrLaby != null)
		charge = arrLaby;
	else
		charge = recup2D();

//	console.log(charge);
	if (coldep!=null)console.log(coldep);
	var posi = charge[3] + charge[2];
	var posi2 = charge[5] + charge[4];
	document.getElementById("plateau").style.display = 'none';
	document.getElementById("coul").style.display = 'none';
	document.getElementById("boutonsaff").style.display = 'none';
	document.getElementById("titreOptions").style.display = 'none';
	document.getElementById("blocker").style.display = 'inline';
	var blocker = document.getElementById('blocker');
	var instructions = document.getElementById('instructions');


	var havePointerLock = 'pointerLockElement' in document || 'mozPointerLockElement' in document || 'webkitPointerLockElement' in document;

	if (havePointerLock) {//vérifie la compatibilité du navigateur (fonctionne sous chrome, et firefox si à jour)

		var element = document.body;

		var pointerlockchange = function(event) {

			if (document.pointerLockElement === element || document.mozPointerLockElement === element || document.webkitPointerLockElement === element) {

				controlsEnabled = true;
				controls.enabled = true;

				blocker.style.display = 'none';

			}
			else {

				controls.enabled = false;

				blocker.style.display = '-webkit-box';
				blocker.style.display = '-moz-box';
				blocker.style.display = 'box';

				instructions.style.display = '';

			}

		}

		var pointerlockerror = function(event) {

			instructions.style.display = '';

		}
		document.addEventListener('pointerlockchange', pointerlockchange, false);
		document.addEventListener('mozpointerlockchange', pointerlockchange, false);
		document.addEventListener('webkitpointerlockchange', pointerlockchange, false);

		document.addEventListener('pointerlockerror', pointerlockerror, false);
		document.addEventListener('mozpointerlockerror', pointerlockerror, false);
		document.addEventListener('webkitpointerlockerror', pointerlockerror, false);

		instructions.addEventListener('click', function(event) {

			instructions.style.display = 'none';

			element.requestPointerLock = element.requestPointerLock || element.mozRequestPointerLock || element.webkitRequestPointerLock;

			if (/Firefox/i.test(navigator.userAgent)) {

				var fullscreenchange = function(event) {

					if (document.fullscreenElement === element || document.mozFullscreenElement === element || document.mozFullScreenElement === element) {

						document.removeEventListener('fullscreenchange', fullscreenchange);
						document.removeEventListener('mozfullscreenchange', fullscreenchange);

						element.requestPointerLock();
					}

				}

				document.addEventListener('fullscreenchange', fullscreenchange, false);
				document.addEventListener('mozfullscreenchange', fullscreenchange, false);

				element.requestFullscreen = element.requestFullscreen || element.mozRequestFullscreen || element.mozRequestFullScreen || element.webkitRequestFullscreen;

				element.requestFullscreen();

			}
			else {

				element.requestPointerLock();

			}

		}, false);

	}
	else {

		instructions.innerHTML = 'Your browser doesn\'t seem to support Pointer Lock API';

	}

	init();
	animate();

	var controlsEnabled = false;

	var moveForward = false;
	var moveBackward = false;
	var moveLeft = false;
	var moveRight = false;

	var prevTime = performance.now();
	var velocity = new THREE.Vector3();
//initialise la scene : place les murs, la caméra, la lumière, etc...
	function init() {

		camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 1, 500);

		scene = new THREE.Scene();
		scene.fog = new THREE.Fog(0xffffff, 0, 750);

		var light = new THREE.HemisphereLight(0xeeeeff, 0x777788, 0.75);
		light.position.set(0.5, 1, 0.75);
		scene.add(light);

		controls = new THREE.PointerLockControls(camera);
		controls.getObject().translateX(5+(10*charge[2]));// permet de placer le personnage sur la case de départ au début de la partie
		controls.getObject().translateY(-7);// déplace la caméra vers le bas : le personnage se trouvera a une hauteur raisonnable
		controls.getObject().translateZ(-5-(10*charge[3]));// permet de placer le personnage sur la case de départ au début de la partie
		scene.add(controls.getObject());

		var onKeyDown = function(event) {

			switch (event.keyCode) {//gère les déplacements par clavier

				case 38: // up
				case 90: // z
					moveForward = true;
					break;

				case 37: // left
				case 81: // q
					moveLeft = true;
					break;

				case 40: // down
				case 83: // s
					moveBackward = true;
					break;

				case 39: // right
				case 68: // d
					moveRight = true;
					break;



			}

		};

		var onKeyUp = function(event) {

			switch (event.keyCode) {

				case 38: // up
				case 90: // z
					moveForward = false;
					break;

				case 37: // left
				case 81: // q
					moveLeft = false;
					break;

				case 40: // down
				case 83: // s
					moveBackward = false;
					break;

				case 39: // right
				case 68: // d
					moveRight = false;
					break;

			}

		};

		document.addEventListener('keydown', onKeyDown, false);
		document.addEventListener('keyup', onKeyUp, false);

		raycaster = new THREE.Raycaster(new THREE.Vector3(), new THREE.Vector3(1, 0, 0), 0, 2);// crée les raycasters, utilisés plus loin pour détecter les collisions avec les murs
		raycaster2 = new THREE.Raycaster(new THREE.Vector3(), new THREE.Vector3(-1, 0, 0), 0, 2);// 4 sont crées, un pour chaque direction ( devant, derrière, gauche, droite)
		raycaster3 = new THREE.Raycaster(new THREE.Vector3(), new THREE.Vector3(0, 0, 1), 0, 2);//les 2 derniers paramètres indique la distance minimale et maximale de la détection.
		raycaster4 = new THREE.Raycaster(new THREE.Vector3(), new THREE.Vector3(0, 0, -1), 0, 2);
		var geometry = new THREE.Geometry();

		//positionne 200 points dans l'espace
		for (var i = 0; i < 10; i++)
			for (var j = 0; j < 10; j++)
				for (var k = 0; k < 2; k++)
					geometry.vertices[i + 10 * j + 100 * k] = new THREE.Vector3(10 * i, 10 * j, 10 * k);

		//fonction récupérée sur l'exemple de Luca De Feo
		function add_carre(geom, p1, p2, p3, p4, color) {
			var reps = new THREE.Face3(p1, p2, p3);
			reps.color.setHex(color);
			geom.faces.push(reps);
			var reps = new THREE.Face3(p1, p3, p4);
			reps.color.setHex(color);
			geom.faces.push(reps);
			var reps = new THREE.Face3(p1, p3, p2);
			reps.color.setHex(color);
			geom.faces.push(reps);
			var reps = new THREE.Face3(p1, p4, p3);
			reps.color.setHex(color);
			geom.faces.push(reps);
		}
		var rouge = 0xff0000;
		var vert = 0x00ff00;
		var blanc = 0xffffff;
		var noir = 0x181616;
		var jaune = 0xffff00;

		//crée le plancher, plafond, les bords du labyrinthe, et les cases de depart et arrivée.
		add_carre(geometry, 0, 90, 99, 9, blanc);
		add_carre(geometry, 100, 190, 199, 109, blanc);
		add_carre(geometry, 0, 100, 109, 9, blanc);
		add_carre(geometry, 9, 109, 199, 99, blanc);
		add_carre(geometry, 99, 199, 190, 90, blanc);
		add_carre(geometry, 0, 100, 190, 90, blanc);
		add_carre(geometry, parseInt(posi), parseInt(posi) + 10, parseInt(posi) + 11, parseInt(posi) + 1, 0x8888ff);
		add_carre(geometry, parseInt(posi2), parseInt(posi2) + 10, parseInt(posi2) + 11, parseInt(posi2) + 1, rouge);


//crée les murs du labyrinthe
		for (j = 0; j < 8; j++) {
			for (i = 0; i < 9; i++) {
				if (charge[0][i][j] == 1)
					add_carre(geometry, (j + 1) * 10 + i, 100 + (j + 1) * 10 + i, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, noir);
				else if (charge[0][i][j] == 2)
					add_carre(geometry, (j + 1) * 10 + i, 100 + (j + 1) * 10 + i, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, rouge);
				else if (charge[0][i][j] == 3)
					add_carre(geometry, (j + 1) * 10 + i, 100 + (j + 1) * 10 + i, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, vert);
				else if (charge[0][i][j] == 4)
					add_carre(geometry, (j + 1) * 10 + i, 100 + (j + 1) * 10 + i, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, jaune);
			}
		}

		for (j = 0; j < 9; j++) {
			for (i = 0; i < 8; i++) {
				if (charge[1][i][j] == 1)
					add_carre(geometry, j * 10 + i + 1, 100 + j * 10 + i + 1, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, noir);
				if (charge[1][i][j] == 2)
					add_carre(geometry, j * 10 + i + 1, 100 + j * 10 + i + 1, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, rouge);
				if (charge[1][i][j] == 3) {
					add_carre(geometry, j * 10 + i + 1, 100 + j * 10 + i + 1, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, vert);
				}
				if (charge[1][i][j] == 4)
					add_carre(geometry, j * 10 + i + 1, 100 + j * 10 + i + 1, 101 + (j + 1) * 10 + i, 1 + (j + 1) * 10 + i, jaune);
			}
		}

		geometry.computeFaceNormals();
		var material = new THREE.MeshLambertMaterial({
			vertexColors: THREE.FaceColors
		});

		var mesh = new THREE.Mesh(geometry, material);
		mesh.rotation.x = -Math.PI / 2; //change l'orientation du labyrinthe pour le "mettre à plat"
		scene.add(mesh);
		objects.push(mesh);

		renderer = new THREE.WebGLRenderer();
		renderer.setClearColor(0xffffff);
		renderer.setPixelRatio(window.devicePixelRatio);
		renderer.setSize(window.innerWidth, window.innerHeight);
		document.body.appendChild(renderer.domElement);

		//

		window.addEventListener('resize', onWindowResize, false);

	}

	function onWindowResize() {

		camera.aspect = window.innerWidth / window.innerHeight;
		camera.updateProjectionMatrix();

		renderer.setSize(window.innerWidth, window.innerHeight);

	}


	function animate() {

		requestAnimationFrame(animate);

		if (controlsEnabled) {
			raycaster.ray.origin.copy(controls.getObject().position);
			raycaster2.ray.origin.copy(controls.getObject().position);
			raycaster3.ray.origin.copy(controls.getObject().position);
			raycaster4.ray.origin.copy(controls.getObject().position);
			var intersections = raycaster.intersectObjects(objects);//intersections détermine si raycaster a obtenu une collision.
			var intersections2 = raycaster2.intersectObjects(objects);
			var intersections3 = raycaster3.intersectObjects(objects);
			var intersections4 = raycaster4.intersectObjects(objects);
			var time = performance.now();
			var delta = (time - prevTime) / 1000;

			velocity.x -= velocity.x * 10.0 * delta;// permet d'avoir un déplacement plus "fluide" : le joueur ralentit doucement après avoir arreté de se déplacer.
			velocity.z -= velocity.z * 10.0 * delta;

			if (moveForward) {
				velocity.z -= 100.0 * delta;
			}
			if (moveBackward) {
				velocity.z += 100.0 * delta;
			}

			if (moveLeft) {
				velocity.x -= 100.0 * delta;

			}
			if (moveRight) {
				velocity.x += 100.0 * delta;
			}
			// si le joueur déclenche une collision en se déplaçant, on le déplace dans la direction opposée au mur.
			if (intersections.length > 0)
			{	
				controls.getObject().position.x -= 0.25;
					document.getElementById("bump").play();// lors de la collision, un son est joué.
			}
			if (intersections2.length > 0)
			{
				controls.getObject().position.x += 0.25;
				document.getElementById("bump").play();
			}
			if (intersections3.length > 0)
			{	
				controls.getObject().position.z -= 0.25;
				document.getElementById("bump").play();
			}
			if (intersections4.length > 0)
			{
				controls.getObject().position.z += 0.25;
				document.getElementById("bump").play();
		
			}
			
	if(controls.getObject().position.x<10+(10*charge[4]) 
	&& controls.getObject().position.x>(10*charge[4]) 
	&& controls.getObject().position.z<-(10*charge[5])
	&& controls.getObject().position.z>-10-(10*charge[5])
	)
	{
		alert("félicitations : vous avez terminé le labyrinthe "+charge[6]);
		window.location.replace("https://labyrinthe-lucasep.c9.io/html/index.html");
	}

			controls.getObject().translateX(velocity.x * delta);
			controls.getObject().translateZ(velocity.z * delta);
			prevTime = time;

		}

		renderer.render(scene, camera);


	}
};



table.addEventListener('click', action, false);
